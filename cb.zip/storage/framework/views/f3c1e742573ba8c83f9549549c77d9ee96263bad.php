<?php $__env->startSection('content'); ?>
  <div class="row">
	
<div class="col-md-6 col-md-offset-3">

<div class="panel panel-default">
	<div class="panel-heading">
		<h1>Search for any book here:</h1>
		</div>
<div class="panel-body">

<form method="POST" action="/search" enctype="multipart/form-data">

<?php echo e(csrf_field()); ?>

	<div class="form-group">
		
                       
        <div class="panel row">
        <div class=" col-md-12">
      		<input id="search" type="text" class="form-control col-md-12" name="searchname" placeholder="Type book name here...">
    		</div>
        </div>
     
<div class="panel-footer">
	<input type="submit" class="btn btn-success pull-right" value="Search">
</div>
</form>
	
</div>
</div>

</div>
	

</div>

</div>



<div class="row">

	<?php $__empty_1 = true; $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
		<div class="col-md-6 col-md-offset-3">

			<div class="panel panel-default">
				<div class="panel-heading"> <?php echo e($result->filepath); ?> </div>
				<div class="panel-body">
				<span><?php echo e($result->content); ?></span>
				</div>
				<div class="panel-footer"><a href="/books/<?php echo e($result->id); ?>">Read this book</a>
				</div>
			</div>
		</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
		<div class="">
  <div class="">
    <h1></h1>
  </div>
</div>
	<?php endif; ?>	
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>