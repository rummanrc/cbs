<?php $__env->startSection('content'); ?>




<h1>Currently reading: <?php echo e($book->filepath); ?></h1>
<iframe src="/pdfjs/web/viewer.html?file=bookstore/<?php echo e($book->filepath); ?>.pdf" style="border: 0" width="100%" height="800" frameborder="0" scrolling="no"></iframe>

<div class="panel col-md-8">
<form method="POST" action="/comments" enctype="multipart/form-data">

<?php echo e(csrf_field()); ?>

	<div class="form-group">
            <label class="col-md-3 control-label" name="resume">Write a comment:</label>
           <!--input  type="text" id="filepath" placeholder="Book Name" name="filepath" class=""/-->
	<TEXTAREA name="comment_body" class="form-control"></TEXTAREA>
	<input type="hidden" name="book_id" value="<?php echo e($book->id); ?>">
	<input type="submit" class="btn btn-success pull-right">
</form>
</div>
</br></br>
<?php $__currentLoopData = $book->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="panel">
		<div class="panel panel-info">
		<div class="panel-heading"> <?php echo e($comment->user->name); ?> </div>
				<div class="panel-body">
					<?php echo e($comment->comment_body); ?>

			</div>
			<div class="panel-footer"><?php echo e($comment->created_at); ?>

				<?php if((Auth::user()->id) == $book->user_id): ?>
				<form action="/comments/<?php echo e($comment->id); ?>" class="pull-right" method="POST">
				<?php echo e(csrf_field()); ?>

				<?php echo e(method_field('DELETE')); ?>

				<button href="/comments/<?php echo e($comment->id); ?>" class="btn btn-danger btn-sm">Delete this comment</button>
				</form>
				<?php endif; ?>

			</div>
		</div>
	</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>