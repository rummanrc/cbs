<?php $__env->startSection('content'); ?>

<div class="row">
	<?php $__empty_1 = true; $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
		<div class="col-md-6 col-md-offset-3">
			<div class="panel panel-default">
				<div class="panel-heading"> <?php echo e($book->filepath); ?> </div>
				<div class="panel-body">
				<span><?php echo e($book->content); ?></span>
				</div>
				<div class="panel-footer"><a href="/books/<?php echo e($book->id); ?>">Read this book</a>
				<?php if((Auth::user()->id) == $book->user_id): ?>
				<form action="/books/<?php echo e($book->id); ?>" class="pull-right" method="POST">
				<?php echo e(csrf_field()); ?>

				<?php echo e(method_field('DELETE')); ?>

				<button href="/books/<?php echo e($book->id); ?>" class="btn btn-danger btn-sm">Delete this book</button>
				</form>
				<?php endif; ?>
				</div>
			</div>
		</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
		<div class="container">
  <div class="jumbotron">
    <h1>No Books Available</h1>
  </div>
</div>
	<?php endif; ?>	
</div>

<div class="col-md6 col-md-offset-3">
	<?php echo e($books->links()); ?>

</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>